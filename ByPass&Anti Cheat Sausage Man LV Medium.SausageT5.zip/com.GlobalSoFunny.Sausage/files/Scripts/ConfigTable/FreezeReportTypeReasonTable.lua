local FreezeReportTypeReasonTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeReportTypeReasonTableBase"))

--------------------------------------------自动生成--------------------------------------------

return FreezeReportTypeReasonTable
