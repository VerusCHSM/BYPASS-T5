local EmulatorPunishLevelTable = class({}, Assets.req("Scripts.ConfigTable.Base.EmulatorPunishLevelTableBase"))

--------------------------------------------自动生成--------------------------------------------

return EmulatorPunishLevelTable
